package file1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;

public class FileConverterGUI2 extends JFrame {

	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = Logger.getLogger(FileConverterGUI2.class.getName());

    private JTextField jsonFileTextField;
    private JTextField csvFileTextField;
    private JTextArea logTextArea;

    public FileConverterGUI2() {
        super("JSON to CSV and CSV to JSON Converter");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        jsonFileTextField = new JTextField(20);
        csvFileTextField = new JTextField(20);

        JButton jsonToCsvButton = new JButton("JSON to CSV");
        JButton csvToJsonButton = new JButton("CSV to JSON");

        jsonToCsvButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertJsonToCsv();
            }
        });

        csvToJsonButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertCsvToJson();
            }
        });

        // Log area to display messages
        logTextArea = new JTextArea(10, 30);
        logTextArea.setEditable(false);
        JScrollPane logScrollPane = new JScrollPane(logTextArea);

        // Layout
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.add(createLabel("JSON File:", Color.BLUE));
        inputPanel.add(jsonFileTextField);
        inputPanel.add(createLabel("CSV File:", Color.BLUE));
        inputPanel.add(csvFileTextField);
        inputPanel.add(jsonToCsvButton);
        inputPanel.add(csvToJsonButton);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(logScrollPane, BorderLayout.CENTER);

        add(mainPanel);

        pack();
        setLocationRelativeTo(null); // Center the frame
        setVisible(true);
    }
        private JTextField createTextField() {
            JTextField textField = new JTextField(20);
            textField.setFont(new Font("Arial", Font.PLAIN, 14));
            textField.setBackground(Color.LIGHT_GRAY);
            textField.setForeground(Color.BLACK);
            return textField;
        
    }
    private JLabel createLabel(String text, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(color);
        return label;
    }

    private void convertJsonToCsv() {
        try {
            Path jsonFilePath = chooseFile("Select JSON File", JFileChooser.FILES_ONLY);
            if (jsonFilePath == null) {
                return; // User canceled file selection
            }

            String jsonFile = jsonFilePath.toString();
            jsonFileTextField.setText(jsonFile);

            String jsonContent = new String(Files.readAllBytes(jsonFilePath));
            JSONArray jsonArray = new JSONArray(jsonContent);

            if (jsonArray.length() > 0) {
                JSONObject firstObject = jsonArray.getJSONObject(0);
                String[] headers = firstObject.keySet().toArray(new String[0]);

                Path csvFilePath = chooseFile("Select CSV File to Save", JFileChooser.FILES_ONLY);
                if (csvFilePath == null) {
                    return; // User canceled file selection
                }

                String csvFile = csvFilePath.toString();
                csvFileTextField.setText(csvFile);

                try (FileWriter fileWriter = new FileWriter(csvFile)) {
                    fileWriter.write(CDL.toString(jsonArray));
                    showMessage("Conversion from JSON to CSV successful!");
                }
            } else {
                showError("JSON file is empty.");
            }
        } catch (IOException | RuntimeException e) {
            logError("Error converting from JSON to CSV", e);
            showError("Conversion failed. Error: " + e.getMessage());
        }
    }

    private void convertCsvToJson() {
        try {
            Path csvFilePath = chooseFile("Select CSV File", JFileChooser.FILES_ONLY);
            if (csvFilePath == null) {
                return; // User canceled file selection
            }

            String csvFile = csvFilePath.toString();
            csvFileTextField.setText(csvFile);

            BufferedReader reader = new BufferedReader(new FileReader(csvFile));
            String line;
            JSONArray jsonArray = new JSONArray();

            // Assuming the first line of CSV is the header
            String[] headers = reader.readLine().split(",");
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                JSONObject jsonObject = new JSONObject();
                for (int i = 0; i < headers.length; i++) {
                    jsonObject.put(headers[i], data[i]);
                }
                jsonArray.put(jsonObject);
            }

            Path jsonFilePath = chooseFile("Select JSON File to Save", JFileChooser.FILES_ONLY);
            if (jsonFilePath == null) {
                return; // User canceled file selection
            }

            String jsonFile = jsonFilePath.toString();
            jsonFileTextField.setText(jsonFile);

            try (FileWriter fileWriter = new FileWriter(jsonFile)) {
                fileWriter.write(jsonArray.toString(2));
                showMessage("Conversion from CSV to JSON successful!");
            }
        } catch (IOException | RuntimeException e) {
            logError("Error converting from CSV to JSON", e);
            showError("Conversion failed. Error: " + e.getMessage());
        }
    }

    private Path chooseFile(String dialogTitle, int selectionMode) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(dialogTitle);
        fileChooser.setFileSelectionMode(selectionMode);

        int result = fileChooser.showDialog(this, "Select");
        if (result == JFileChooser.APPROVE_OPTION) {
            return fileChooser.getSelectedFile().toPath();
        } else {
            return null;
        }
    }

    private void showMessage(String message) {
        logTextArea.append(message + "\n");
        logTextArea.setCaretPosition(logTextArea.getDocument().getLength());
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showError(String message) {
        logTextArea.append("Error: " + message + "\n");
        logTextArea.setCaretPosition(logTextArea.getDocument().getLength());
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void logError(String message, Throwable throwable) {
        LOGGER.log(Level.SEVERE, message, throwable);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileConverterGUI2();
            }
        });
    }
}

